# Plan 003 — Cuenta y autenticación (backend)

- **Spec:** `spec.md` · **Dueño:** BE-A

## 1. Estructura
```
internal/auth/
  domain/{user.go, errors.go}
  usecase/{register.go, login.go, refresh.go, logout.go, profile.go, deactivate.go, ports.go}
  adapter/http/{handler.go, dto.go, middleware.go, routes.go}
  adapter/mongo/{user_repo.go, refresh_repo.go}
internal/platform/{security/{password.go, jwt.go, tokens.go}, ratelimit/limiter.go}
internal/notify/{notifier.go}        # puerto + implementación vacía
internal/moderation/{checker.go}     # puerto + implementación vacía
internal/config/auth.go
cmd/api/modules.go · cmd/admin/create_admin.go
api/paths/auth.yaml · api/paths/users.yaml
```

## 2. Contrato (resumen; el detalle va en `api/paths/auth.yaml`)
| Método | Ruta | Auth | Cuerpo → Respuesta |
|---|---|---|---|
| POST | `/api/v1/auth/register` | — | `{email,password,displayName,acceptTerms,isAdult}` → 201 `{user,tokens}` |
| POST | `/api/v1/auth/login` | — | `{email,password}` → 200 `{user,tokens}` |
| POST | `/api/v1/auth/refresh` | — | `{refreshToken}` → 200 `{tokens}` |
| POST | `/api/v1/auth/logout` | — | `{refreshToken}` → 204 |
| GET | `/api/v1/me` | Sí | → 200 `User` |
| PATCH | `/api/v1/me` | Sí | `{displayName?,phone?}` → 200 `User` |
| DELETE | `/api/v1/me` | Sí | `{password}` → 204 |
| GET | `/api/v1/users/{id}` | Sí | → 200 `PublicUser` |

```
Tokens     = { accessToken, refreshToken, expiresIn }        # expiresIn en segundos
User       = { id, email, displayName, phone|null, role, ratingAverage|null, ratingCount, createdAt }
PublicUser = { id, displayName, ratingAverage|null, ratingCount, memberSince }
```

## 3. Datos (MongoDB)
**`users`**: `_id`, `email` (único, minúsculas), `passwordHash`, `displayName`, `phone`, `role`, `status` (`active`|`deactivated`), `acceptedTermsAt`, `ratingSum` (int), `ratingCount` (int), `suspendedUntil`, `createdAt`, `updatedAt`, `version`, `deactivatedAt`.
Índices: único `{email:1}`.
**`refresh_tokens`**: `_id`, `userId`, `familyId`, `tokenHash` (SHA-256), `expiresAt`, `usedAt`, `revokedAt`, `createdAt`.
Índices: único `{tokenHash:1}`; `{familyId:1}`; TTL `{expiresAt:1}` con `expireAfterSeconds:0`.

## 4. Decisiones
| # | Decisión | Art. |
|---|---|---|
| P-01 | `argon2id` (`x/crypto/argon2`): m=64 MiB, t=3, p=2, sal 16 B; formato PHC en cadena | VI |
| P-02 | JWT HS256 (`golang-jwt/jwt/v5`), claims `sub`, `role`, `exp`, `iat`, `jti`; secreto `JWT_ACCESS_SECRET` (≥ 32 caracteres) | VI |
| P-03 | Refresco: 32 bytes aleatorios en base64url; se guarda solo su hash | VI |
| P-04 | Rotación con detección de reutilización: si llega un token con `usedAt` → revocar la familia | VI |
| P-05 | Límite de tasa en memoria por IP (ventana deslizante); válido para una sola instancia (staging); se documenta | VIII |
| P-06 | `Module` interface y `modules.go` con una línea por módulo | XII |
| P-07 | `auth.UserID(ctx)` y `auth.Role(ctx)` son el único modo de leer la identidad | III |
| P-08 | Baja: `status=deactivated`, `deactivatedAt`, se revocan todos los refresh; el correo se conserva (impide reusarlo) | VI |
| P-09 | Validación con `go-playground/validator/v10` en DTOs; mensajes en español | VI |
| P-10 | Comprobación de reservas activas mediante puerto `ActiveBookingChecker` (vacío = false hasta 007) | XII |

## 5. Variables nuevas
`JWT_ACCESS_SECRET` (obligatoria, ≥ 32), `JWT_ACCESS_TTL` (15m), `REFRESH_TTL` (720h), `RATE_LIMIT_AUTH_PER_MIN` (10).

## 6. Dependencias nuevas (aprobadas por Art. VIII.4)
`github.com/go-playground/validator/v10`, `golang.org/x/crypto`, `github.com/golang-jwt/jwt/v5`.

## 7. Pruebas
Unitarias de cada caso de uso con repos falsos; `password` (hash/verify, formato); `jwt` (firma, expiración, algoritmo incorrecto rechazado); rotación y reutilización; límite de tasa. Integración (testcontainers): registro→login→refresh→logout, índice único de correo, TTL presente.

## 8. Verificación de constitución
| Art. | Cumple |
|---|---|
| III | Capas por módulo; el dominio no importa `jwt` ni `mongo` |
| IV | Errores con el envoltorio; `openapi` primero |
| VI | argon2id, sin secretos en logs, límite de intentos |
| VII | ≥ 80 % en domain/usecase |
| XII | `modules.go`, puertos vacíos, contrato en `api/paths/` |

## 9. Ajustes durante la implementación (2026-11-06, [BE-B])
| # | Ajuste | Motivo |
|---|---|---|
| A-01 | **P-05 sustituida:** el límite de `register`, `login` y `refresh` usa el middleware `RateLimit` de la spec 002 (Redis con respaldo en memoria) con `KeyPrefix: "auth:"`; no se crea `internal/platform/ratelimit` | Art. XIV.1–2 (constitución 1.5.0) exige API sin estado y límite en Redis; P-05 venía de la v1.4.0 |
| A-02 | Puertos compartidos `users.Directory` y `users.Admin` en `internal/users/` (implementados por `auth/adapter/mongo.UserRepo`) | T008; los consumen 005–011 sin importar el módulo auth |
| A-03 | `security.Hasher` calcula como máximo un hash argon2id a la vez (64 MiB cada uno) | La API tiene 160 MiB en la VM (Art. XIV.5) |
| A-04 | La baja **anonimiza** el correo (`deleted+<id>@vaiven.invalid`) en lugar de conservarlo (P-08) | T008 y RF-08: el correo original debe poder registrarse de nuevo |
| A-05 | `DELETE /me` con contraseña incorrecta responde **403** `forbidden`, no 401 | Que el móvil no lo confunda con una sesión vencida |
| A-06 | La prueba de arquitectura cubre `internal/<modulo>/{domain,usecase}` y los puertos compartidos | Art. III y XII.3 |
| A-07 | **Enmienda de P-01 (pendiente de aprobación de BE-A y del equipo):** argon2id pasa de m=64 MiB, t=3, p=2 a **m=19 MiB, t=2, p=1** (configuración mínima recomendada por OWASP Password Storage Cheat Sheet). Los hashes ya guardados siguen verificando: `Verify` lee los parámetros de cada hash. Los hashes en curso comparten un presupuesto de 40 MiB (2 nuevos a la vez; uno antiguo de 64 MiB se calcula solo) y la espera de turno se corta a los 2 s con 503 `service_unavailable`. El hash señuelo del login se calcula al arrancar | Auditoría 2026-11-07: con los parámetros anteriores un solo hash dejaba el proceso en ~131 MiB de 160 y el login daba ~7 hash/s; con los nuevos, medido con 2 CPU y 160 MiB: ~50 ms por hash, ~39 hash/s con 2 en paralelo y ~103 MiB de pico. Costo: por adivinanza fuera de línea el atacante paga ~5 veces menos (memoria × iteraciones), dentro del mínimo de OWASP; se compensa con el límite por cuenta (A-08) |
| A-08 | Límite de **20 intentos de login por cuenta cada 15 min** (`LOGIN_ATTEMPTS_PER_ACCOUNT`), además de 10/min por IP. La clave en Redis es el SHA-256 del correo normalizado | Relleno de credenciales desde muchas IP (auditoría 2026-11-07). Riesgo aceptado: alguien puede bloquear 15 min el login de una cuenta ajena con 20 intentos |
| A-09 | `$jsonSchema` en `users` y `refresh_tokens` (constitución §6.6), nivel `moderate`, sin `additionalProperties: false` (`internal/auth/adapter/mongo/schema.go`). `cmd/api` la aplica al arrancar antes de los índices; si la colección ya existe y el usuario de la app no tiene `collMod` (rol readWrite), avisa en el log y sigue | Integridad de datos; `moderate` no invalida documentos antiguos |
